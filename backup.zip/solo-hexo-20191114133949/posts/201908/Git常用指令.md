title: Git常用指令
date: '2019-08-29 17:05:17'
updated: '2019-08-29 17:07:45'
tags: [Git]
permalink: /articles/2019/08/29/1567069517813.html
---
# git常用指令

## 检出更新提交
---
检出
```
git clone url
```
更新
```
git pull
```

添加文件
```
git add 文件名
```

添加所有文件
```
git add -a
```
提交文件至本地仓库
```
git commit -m 提交说明
```

将本地仓库推送到服务器
```
git push
```
---


## 分支

---
显示本地分支
``` 
git branch
``` 
显示所有包括服务器分支
```
git branch -a
```
切换分支
```
git checkout 分支名
```
新建本地分支并切换
```
git checkout -b 分支名
```
将本地分支推送至服务器
```
git push origin 远程分支名:本地分支名
```
---
