title: ES6学习--Map
date: '2019-08-30 13:32:23'
updated: '2019-08-30 13:32:23'
tags: [ES6]
permalink: /articles/2019/08/30/1567143142958.html
---
## Map初始化
```
// 仅仅初始化不赋值
1.  let mapInit = new Map()
// 初始化并赋值
2.  let mapInit = new Map([['key1','value1'], ['key2', 'value2']])
```

## Map 赋值
```
mapInit.set('key3','value3')
```

## Map 取值
```
let value2 = mapInit.get('key2')
console.log(value2) //输出内容为：value2
```
