title: Linux服务器开启MySql数据库root远程连接
date: '2019-08-30 14:37:29'
updated: '2019-08-30 14:40:37'
tags: [Linux, MySQL]
permalink: /articles/2019/08/30/1567147049590.html
---
## 在Linux登录MySql服务
``` sql
mysql -u root -p;
```
> -u 指用户名 -p 指密码，以上指令则为以root用户通过密码登录

## 创建远程连接MySql的用户
``` sql
GRANT ALL PRIVILEGES ON *.* TO 'root'@'192.168.0.2' IDENTIFIED BY 'root' WITH GRANT OPTION; 
```
> 说明：
	第一个root为远程登录用户名；
	192.168.0.2为允许登录的IP，如需所有人登录，则将IP地址替换为%；
	第二个root为登录密码

## 将上述设置立即生效
``` sql
FLUSH PRIVILEGES;
```

## 查看MySql所有登录用户详情
``` sql
use mysql;
SELECT DISTINCT CONCAT('User: [', user, '''@''', host, '];') AS USER_HOST FROM user;
```
> 如果查询的结果有上述设置的用户，则修改成功

## 开启防火墙
如果电脑开启防火墙中，则需要将MySql所使用的端口在防火墙中放行
